
#include <iostream>
using namespace std;

int main()
{
    /*cout << "Dame el mes: (1, 2, ..., 12): ";
    int mes;
    cin >> mes;
    while (mes < 1 || mes > 12)
    {
        cout << "El valor introducido no es válido.\n";
        cout << "Dame el mes: (1, 2, ..., 12): ";
        cin >> mes;
    }*/
    int i =0;
    while (i < 5)
    {
        cout<<"el valor de i es :"<< i<<"\n";
        i++; //i = i+1;
        /* code */
    }
    
    return 0;
}
