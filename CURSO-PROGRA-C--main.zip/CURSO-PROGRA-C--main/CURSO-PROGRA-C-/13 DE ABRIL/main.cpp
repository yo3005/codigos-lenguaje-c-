#include <iostream>
#include <string>
#include "gato.cpp"

using namespace std;

int main(){
    Gato  gat(3,"Felinos");

    gat.getDatos();
    return 0;
}
